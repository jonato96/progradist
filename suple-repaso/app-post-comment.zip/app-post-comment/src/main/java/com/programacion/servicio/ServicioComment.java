package com.programacion.servicio;

public interface ServicioComment {
}
