package com.programacion.servicio;

import com.programacion.db.Comment;
import com.programacion.proxy.PostComment;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.List;

//@Path("/comentarios")
//@ApplicationScoped
public class ServicioCommentImp {

//    @Inject
//    private PostComment servicio;
//
//
//    @GET
//    @Produces(MediaType.APPLICATION_JSON)
//    public List<Comment> todos(){
//        return servicio.listarComments();
//    }

}
