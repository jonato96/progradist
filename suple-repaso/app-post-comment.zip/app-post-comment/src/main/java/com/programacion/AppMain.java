package com.programacion;

public class AppMain {

    public static void main(String[] args) {
        io.helidon.microprofile.cdi.Main.main(args);
    }

}
